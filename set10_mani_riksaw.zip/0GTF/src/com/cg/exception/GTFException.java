package com.cg.exception;

public class GTFException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8947510395471701442L;

	public GTFException() {
		// TODO Auto-generated constructor stub
	}

	public GTFException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	

}
