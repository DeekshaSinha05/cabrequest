package com.cg.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.bean.QueryBean;
import com.cg.exception.GTFException;
import com.cg.service.IService;

@org.springframework.stereotype.Controller
public class Controller {
	@Autowired
	IService qService;

	@RequestMapping(value="show")
	public String homePage(){
		return ("index");
	}
	
	
	@RequestMapping(value="search",method = RequestMethod.POST)
	public ModelAndView search(@RequestParam("id") int id) throws GTFException{
		ModelAndView mv=new ModelAndView();
		try {
			QueryBean bean = qService.searchQry(id);
			if(bean!=null){
			mv.setViewName("update");
			mv.addObject("bean", bean);
			}
			else{
				mv.setViewName("errorIdNotFound");
				mv.addObject("id", "Record not found");
			}
			
		} catch (GTFException e) {
			mv.setViewName("errorIdNotFound");
			mv.addObject("id", e);
		}
		return mv;
	}
	
	@RequestMapping(value="AfterUpdate", method=RequestMethod.POST)
	public ModelAndView AfterUpdate(@ModelAttribute("bean") QueryBean bean, BindingResult result) throws GTFException{
		ModelAndView mv= new ModelAndView();
	
		if(result.hasErrors())
		{
			mv.setViewName("error");
			mv.addObject("message", result);
		}
		else
		{
			try {
				int id=qService.updateQry(bean);
				mv.setViewName("success");
				mv.addObject("id", id);
			} catch (GTFException e) {
			
				mv.setViewName("error");
				mv.addObject("message", e.getMessage());
			}
			
			
		}
		
		
		return mv;
	}
	
}
