package com.cg.dao;

import com.cg.bean.QueryBean;
import com.cg.exception.GTFException;

public interface IDao {
	public QueryBean searchQry(int id) throws GTFException;
	public int updateQry(QueryBean qryBean) throws GTFException;

}
