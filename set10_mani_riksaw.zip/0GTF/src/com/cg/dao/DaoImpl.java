package com.cg.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.bean.QueryBean;
import com.cg.exception.GTFException;
@Repository
@Transactional
public class DaoImpl implements IDao{

	@PersistenceContext
	private EntityManager em;

	@Override
	public QueryBean searchQry(int id) throws GTFException {
		QueryBean bean=em.find(QueryBean.class, id);
	
		return bean;
	}

	@Override
	public int updateQry(QueryBean qryBean) throws GTFException {
		em.merge(qryBean);
		em.flush();
		int id=qryBean.getId();
		return id;
	}

}
