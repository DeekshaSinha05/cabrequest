package com.cg.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="query_master")


public class QueryBean {
	@Id
	@Column(name="query_id")
	private int id;
	@Column(name="technology", length=20)
	private String tech;
	@Column(name="query_raised_by", length=20)
	private String qryBy;
	@Column(name="query", length=20)
	private String qry;
	@Column(name="solutions", length=20)
	private String ans;
	@Column(name="solution_given_by", length=20)
	private String ansBy;
	public QueryBean() {
		super();
	}
	public QueryBean(int id, String tech, String qryBy, String qry, String ans,
			String ansBy) {
		super();
		this.id = id;
		this.tech = tech;
		this.qryBy = qryBy;
		this.qry = qry;
		this.ans = ans;
		this.ansBy = ansBy;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTech() {
		return tech;
	}
	public void setTech(String tech) {
		this.tech = tech;
	}
	public String getQryBy() {
		return qryBy;
	}
	public void setQryBy(String qryBy) {
		this.qryBy = qryBy;
	}
	public String getQry() {
		return qry;
	}
	public void setQry(String qry) {
		this.qry = qry;
	}
	public String getAns() {
		return ans;
	}
	public void setAns(String ans) {
		this.ans = ans;
	}
	public String getAnsBy() {
		return ansBy;
	}
	public void setAnsBy(String ansBy) {
		this.ansBy = ansBy;
	}
	@Override
	public String toString() {
		return "QueryBean [id=" + id + ", tech=" + tech + ", qryBy=" + qryBy
				+ ", qry=" + qry + ", ans=" + ans + ", ansBy=" + ansBy + "]";
	}
	
}
