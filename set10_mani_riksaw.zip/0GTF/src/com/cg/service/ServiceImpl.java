package com.cg.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bean.QueryBean;
import com.cg.dao.IDao;
import com.cg.exception.GTFException;
@Service
public class ServiceImpl implements IService {
 @Autowired
	IDao qDao;
	
	
	@Override
	public QueryBean searchQry(int id) throws GTFException {
		
		return qDao.searchQry(id);
	}

	@Override
	public int updateQry(QueryBean qryBean) throws GTFException {
		
		return qDao.updateQry(qryBean);
	}

}
