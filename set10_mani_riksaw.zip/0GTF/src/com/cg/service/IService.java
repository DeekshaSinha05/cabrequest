package com.cg.service;

import com.cg.bean.QueryBean;
import com.cg.exception.GTFException;

public interface IService {
	public QueryBean searchQry(int id) throws GTFException;
	public int updateQry(QueryBean qryBean) throws GTFException;
}
